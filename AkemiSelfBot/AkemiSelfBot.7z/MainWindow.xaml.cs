﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using Discord.Net;
using Discord.WebSocket;
using Discord;
using MahApps.Metro.Controls.Dialogs;

namespace AkemiSelfBot
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        private static string Token = "mfa.acCPHEFQEePgTygn_PFl--oPv3poo7V9m9h6FPKb_2tPN_7htUnMFKFMY650X0KUWnazcdFM1jw7tt4VNMs1";
        public static DiscordSocketClient Client;
        public static List<GuildHolder> GuildHolders = new List<GuildHolder>();

        private static ulong selectedChannel;

        public MainWindow()
        {
            InitializeComponent();

            Tab1.IsEnabled = true;
            Tab2.IsEnabled = false;
            SaveGridPanel.Visibility = Visibility.Hidden;

            Client = new DiscordSocketClient();

            MainWindowAsync();
        }

        public async Task MainWindowAsync()
        {

        }

        public async Task LoginToToken()
        {
            MetroDialogSettings settings1 = new MetroDialogSettings();
            settings1.DefaultText = Token;
            var message = await this.ShowInputAsync("Enter Discord Token", "This is your client token.", settings1);
            if (message == null)
            {
                return;
            }
            MetroDialogSettings settings = new MetroDialogSettings();
            settings.AffirmativeButtonText = "cancel";
            Token = message.Replace("\"", "").TrimStart().TrimEnd();
            await Connect();
        }

        // "mfa.acCPHEFQEePgTygn_PFl--oPv3poo7V9m9h6FPKb_2tPN_7htUnMFKFMY650X0KUWnazcdFM1jw7tt4VNMs1"
        public async Task Connect()
        {
            try
            {
                await Client.LoginAsync(Discord.TokenType.User, Token);
                await Client.StartAsync();
                Client.MessageReceived += Client_MessageReceived;
            }
            catch (Exception e)
            {
                await this.ShowMessageAsync("Could not connect to Discord", "", MessageDialogStyle.Affirmative);
                LoginToToken();
                return;
            }

            await this.ShowMessageAsync("Connected to Token", "", MessageDialogStyle.Affirmative);
            Tab1.IsEnabled = true;
            Tab2.IsEnabled = true;

            SaveMessagesToggle.Checked += SaveToggleToElement;
            SaveMessagesToggle.Unchecked += SaveToggleToElement;
            SaveMediaToggle.Checked += SaveToggleToElement;
            SaveMediaToggle.Unchecked += SaveToggleToElement;
            SaveMediaPngToggle.Checked += SaveToggleToElement;
            SaveMediaPngToggle.Unchecked += SaveToggleToElement;
            SaveMediaJpegToggle.Checked += SaveToggleToElement;
            SaveMediaJpegToggle.Unchecked += SaveToggleToElement;
            SaveMediaGifToggle.Checked += SaveToggleToElement;
            SaveMediaGifToggle.Unchecked += SaveToggleToElement;
            SaveMediaMp4Toggle.Checked += SaveToggleToElement;
            SaveMediaMp4Toggle.Unchecked += SaveToggleToElement;
        }

        private async Task Client_MessageReceived(SocketMessage arg)
        {
            ToggleChannel channel = GetToggleChannel(arg.Channel.Id);
            if (channel == null) return;
            // use content
            if (channel.SaveMessages)
            {

            }
        }

        private void SaveToggleToElement(object sender, RoutedEventArgs e)
        {
            if (e.Source == SaveMessagesToggle) GetToggleChannel(selectedChannel).SaveMessages = (bool)SaveMessagesToggle.IsChecked;
            else if (e.Source == SaveMediaToggle)
            {
                bool c = (bool)SaveMediaToggle.IsChecked;
                GetToggleChannel(selectedChannel).SaveImages = c;
                SaveMediaPngToggle.IsEnabled = c;
                SaveMediaJpegToggle.IsEnabled = c;
                SaveMediaGifToggle.IsEnabled = c;
                SaveMediaMp4Toggle.IsEnabled = c;
            }
            else if (e.Source == SaveMediaPngToggle) GetToggleChannel(selectedChannel).SavePng = (bool)SaveMediaPngToggle.IsChecked;
            else if (e.Source == SaveMediaJpegToggle) GetToggleChannel(selectedChannel).SaveJpeg = (bool)SaveMediaJpegToggle.IsChecked;
            else if (e.Source == SaveMediaGifToggle) GetToggleChannel(selectedChannel).SaveGif = (bool)SaveMediaGifToggle.IsChecked;
            else if (e.Source == SaveMediaMp4Toggle) GetToggleChannel(selectedChannel).SaveMp4 = (bool)SaveMediaMp4Toggle.IsChecked;
        }

        public async Task ReloadChannelList()
        {
            TreeView tree = ChannelsView;
            try
            {
                SocketGuild[] guilds = Client.Guilds.ToArray();
                List<GuildHolder> holders = new List<GuildHolder>();
                foreach (SocketGuild guild in guilds)
                {
                    holders.Add(new GuildHolder(guild));
                }

                foreach (GuildHolder holder in holders.OrderBy(x => x.Guild.Name))
                {
                    TreeViewItem serverName = new TreeViewItem();
                    serverName.Header = holder.Guild.Name;

                    // add image
                    System.Windows.Controls.Image guildImg = new System.Windows.Controls.Image();
                    guildImg.Source = new BitmapImage(new Uri(@holder.Guild.IconUrl));
                    guildImg.Width = MessagesChannelsList.Width - 20;
                    guildImg.Height = guildImg.Width;
                    MessagesChannelsList.Items.Add(guildImg);

                    foreach (ToggleChannel channel in holder.TextChannels)
                    {
                        TreeViewItem channelItem = new TreeViewItem();
                        channelItem.Selected += ChannelItem_Selected;
                        channelItem.Unselected += ChannelItem_Unselected;
                        CheckBox c = channel.CheckBox;
                        c.Checked += Checkbox_Checked;
                        c.Unchecked += Checkbox_Unchecked;
                        SocketGuildChannel ch = holder.Guild.Channels.FirstOrDefault(x => x.Id == channel.Channel.Id);
                        c.Content = ch.Name;
                        channelItem.Header = c;
                        serverName.Items.Add(channelItem);
                    }
                    tree.Items.Add(serverName);
                }

                GuildHolders = holders;
            }
            catch(Exception e)
            {
                await this.ShowMessageAsync("Error", e.Message, MessageDialogStyle.Affirmative);
            }
        }

        private void ChannelItem_Unselected(object sender, RoutedEventArgs e)
        {
            SaveGridPanel.Visibility = Visibility.Hidden;
        }

        private void ChannelItem_Selected(object sender, RoutedEventArgs e)
        {
            ToggleChannel channel = GetToggleChannel(((TreeViewItem)sender).Header as CheckBox);
            if (channel == null) this.ShowMessageAsync("Error", "No valid Channel found", MessageDialogStyle.Affirmative);

            selectedChannel = channel.Channel.Id;

            SaveMessagesToggle.IsChecked = channel.SaveMessages;
            SaveMediaToggle.IsChecked = channel.SaveImages;
            SaveMediaPngToggle.IsChecked = channel.SavePng;
            SaveMediaJpegToggle.IsChecked = channel.SaveJpeg;
            SaveMediaGifToggle.IsChecked = channel.SaveGif;
            SaveMediaMp4Toggle.IsChecked = channel.SaveMp4;

            SaveMediaPngToggle.IsEnabled = channel.SaveImages;
            SaveMediaJpegToggle.IsEnabled = channel.SaveImages;
            SaveMediaGifToggle.IsEnabled = channel.SaveImages;
            SaveMediaMp4Toggle.IsEnabled = channel.SaveImages;

            SaveGridPanel.Visibility = Visibility.Visible;
        }

        private void Checkbox_Unchecked(object sender, RoutedEventArgs e)
        {
            ToggleChannel channel = GetToggleChannel((CheckBox)sender);
            if (channel == null) this.ShowMessageAsync("Error", "No valid Channel found", MessageDialogStyle.Affirmative);


        }

        private void Checkbox_Checked(object sender, RoutedEventArgs e)
        {
            ToggleChannel channel = GetToggleChannel((CheckBox)sender);
            if(channel == null) this.ShowMessageAsync("Error", "No valid Channel found", MessageDialogStyle.Affirmative);


        }

        public ToggleChannel GetToggleChannel(CheckBox checkBox)
        {
            foreach (GuildHolder gH in GuildHolders)
            {
                ToggleChannel channel = gH.TextChannels.FirstOrDefault(x => x.CheckBox.GetHashCode() == checkBox.GetHashCode());
                if (channel == null) continue;
                return channel;
            }
            return null;
        }

        public ToggleChannel GetToggleChannel(ulong id)
        {
            try
            {
                foreach (GuildHolder gH in GuildHolders)
                {
                    ToggleChannel tC = gH.TextChannels.FirstOrDefault(x => x.Channel.Id == id);
                    if (tC != null)
                    {
                        Console.WriteLine("Found: " + tC.Channel.Name);
                        return gH.TextChannels.FirstOrDefault(x => x.Channel.Id == id);
                    }
                }
            }
            catch (Exception e)
            {
                this.ShowMessageAsync("Error", e.Message, MessageDialogStyle.Affirmative);
            }
            return null;
        }

        private void RefreshChannelsBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ReloadChannelList();
        }

        private void LoginBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            LoginToToken();
        }
    }
}
